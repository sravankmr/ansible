## Run playbook

```
ansible-playbook --inventory inventory/vm-setup-playbook/hosts ansible-handlers-playbook.yml 
```