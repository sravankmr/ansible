## Run playbook

```bash
ansible-playbook --inventory inventory/ansible-env-variable-playbook/hosts ansible-env-variable-playbook.yml
```
