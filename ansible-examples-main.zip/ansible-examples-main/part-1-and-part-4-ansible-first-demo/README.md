## How to run the playbook to connect on Google Cloud VM

```
ansible-playbook --inventory inventory/vm-setup-playbook/hosts vm-setup-playbook.yml 
```