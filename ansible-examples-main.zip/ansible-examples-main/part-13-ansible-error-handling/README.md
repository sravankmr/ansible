## Run playbook

```bash
ansible-playbook --inventory inventory/ansible-error-handling-playbook/hosts ansible-error-handling-playbook.yml
```


## How to find apache is installed or not 

```
type -a apache2 
```


## SSH to EC2 instance

```
ssh -i /Users/rahulwagh/.ssh/aws_ec2_terraform ubuntu@18.198.3.146
```